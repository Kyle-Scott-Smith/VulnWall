# Security Dashboard — Docker Demo Environment

A minimal, general-purpose Vite + React dev container for demoing this app.
It's intentionally "dumb" (no hardcoded routes, pages, or assumptions about
`App.jsx`'s internals) so you can keep building the app without the
environment breaking.

## Run it

```bash
docker compose up --build
```

Then open **http://localhost:5173**.

First run will be a bit slower (npm install inside the image). After that,
`docker compose up` alone is enough — no rebuild needed for code changes.

## How it stays "unbreakable" as the app grows

- **Live bind mount, not a baked-in copy.** `docker-compose.yml` mounts the
  whole project folder into the container. Add new components, new files,
  new folders under `src/` — Vite's dev server picks them up instantly via
  hot module reload. You never need to touch the Dockerfile for this.

- **`node_modules` is isolated in the container**, not your host, via the
  anonymous volume trick (`- /app/node_modules` after the bind mount). This
  means your host doesn't need Node installed at all, and stale/incompatible
  local `node_modules` can't leak in and conflict with the container's.

- **Only `package.json` changes trigger a rebuild.** The Dockerfile copies
  `package*.json` and runs `npm install` in its own layer, before copying
  any source. So:
  - Editing `App.jsx`, adding a new component, restyling → just refresh the
    browser (or let HMR do it). No rebuild.
  - Adding a new npm package (e.g. `npm install some-lib`) → run
    `docker compose up --build` once to pick up the new dependency, then
    back to normal.

- **No app-specific assumptions.** The container doesn't know or care that
  this is a "security dashboard" — it just serves whatever's in `src/` via
  Vite. You can rename components, add routing, add a backend proxy, etc.,
  without editing Docker files, as long as it's still a Vite-served
  frontend.

## Adding a dependency

```bash
docker compose exec app npm install <package-name>
docker compose restart app
```
(or just stop and re-run `docker compose up --build`)

## Adding a real backend later

If you outgrow the in-memory mock data (`accounts`, `vulnRows`, etc. in
`App.jsx`) and want a real API:
1. Add a new service block to `docker-compose.yml` (e.g. `api:`).
2. Point fetch calls in the React app at `http://api:<port>` (compose's
   built-in DNS resolves service names) or expose it on the host and use
   `http://localhost:<port>`.
This compose file is deliberately single-service right now so it's easy to
extend without unwinding existing config.

## Production-style build (optional)

The dev setup above is for demoing/iterating. If you eventually want a
static production build to test:

```bash
docker compose exec app npm run build
docker compose exec app npm run preview
```

## Project layout

```
.
├── Dockerfile
├── docker-compose.yml
├── .dockerignore
├── package.json
├── vite.config.js
├── index.html
└── src/
    ├── main.jsx      # mounts <App />
    └── App.jsx       # the app itself — edit freely
```
